·README - CS3343 Daily-Nutritional-Intake-Monitoring-System (Group 6)

=======================================================================
=======================================================================


	     Daily-Nutritional-Intake-Monitoring-System


=======================================================================

<< Description >>

- Introduction
The Daily Nutritional Intake Monitoring System is an innovative application developed to assist users in maintaining a healthy lifestyle by tracking their daily nutrition intake. In response to the growing focus on health and dietary choices, our group has created this user-friendly tool to provide vital nutritional tracking capabilities.

- Aim of the Program
The primary aim of the program is to bridge existing gaps in nutrition tracking applications. It uniquely addresses user concerns about understanding and reaching optimal nutrition levels. By incorporating a nutrition calculator and a diet recommendation system, the application not only tracks but also advises users on their dietary choices. This leads to more informed decisions and actionable steps towards a nutritious diet and a healthier lifestyle.

- Program Overview
Our application offers a structured approach to monitor daily dietary behaviors. It features functionalities for adding and switching days, importing food types, managing food portions, and calculating total and average nutritional values. Users can seamlessly navigate through these options to track and analyze their nutritional intake effectively.

-----------------------------------------------------------------------


<< Installation >>

- Prerequisite:
Ensure Java Runtime Environment (JRE) is installed on your computer.
Download JRE from Oracle's official website: https://www.oracle.com/java/technologies/downloads/ 

- Launch:
Run launch.bat located in the Release folder to start the program.
For detailed instructions, refer to the User Manual provided in the package.

-----------------------------------------------------------------------

<< User Guideline >>

- Starting the Program: 
Run the provided JAR file. Input commands in the console, separated by “|”.

- Adding and Switching Days: 
Use addDay|{date} to add a new day and switch to it. Dates should be in the format yyyy-mm-dd.

- Listing Days: 
Use listDays to view all created days.

- Managing Food Types:
Import food types with importFoodTypes|{filePath}.
List all food types with listFoodTypes.

- Managing Food Portions:
Add or update food portions with addPortion|{foodName}|{amount}.
Remove food portions with removePortion|{foodName}.
List all portions of the current day with listFoodPortions.

- Calculating Nutrition:
Get total nutrition for the current day using getTotal.
Obtain average nutrition across all days with getAverage.
Receive nutrition recommendations for the current day with getRecommendation.
Exiting the Program: Use quit to exit the program.

-----------------------------------------------------------------------

<< Configuration Management >>

Release 1.0 (Date: 11/12/2023) of the Daily Nutritional Intake Monitoring System encompasses the following programs:

Program file "NutritionCalculator.java"
Beta ver -
Release 1 ver 1.0

Program file "RecommendationSystem.java"
Beta ver -
Release 1 ver 1.0

Program file "DayNotSelectedException.java"
Beta ver -
Release 1 ver 1.0

Program file "InsufficientArgumentsException.java"
Beta ver -
Release 1 ver 1.0

Program file "InvalidDateException.java"
Beta ver -
Release 1 ver 1.0

Program file "ResourceNotFoundException.java"
Beta ver -
Release 1 ver 1.0

Program file "InputParser.java"
Beta ver -
Release 1 ver 1.0

Program file "OutputFormatter.java"
Beta ver -
Release 1 ver 1.0

Program file "Day.java"
Beta ver -
Release 1 ver 1.0

Program file "Food.java"
Beta ver -
Release 1 ver 1.0

Program file "FoodPortion.java"
Beta ver -
Release 1 ver 1.0

Program file "Main.java"
Beta ver -
Release 1 ver 1.0

Program file "NutritionValue.java"
Beta ver -
Release 1 ver 1.0

Program file "User.java"
Beta ver -
Release 1 ver 1.0

Program file "NutritionCalculatorTest.java"
Beta ver -
Release 1 ver 1.0


-----------------------------------------------------------------------
<END>