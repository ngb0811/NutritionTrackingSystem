package exceptions;

public class InvalidDateException extends Exception {
    public InvalidDateException(String m){
        super(m);
    }
}
